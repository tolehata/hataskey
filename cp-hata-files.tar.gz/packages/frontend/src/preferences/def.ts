/*
 * SPDX-FileCopyrightText: syuilo and misskey-project
 * SPDX-License-Identifier: AGPL-3.0-only
 */

import * as Misskey from 'cherrypick-js';
import { hemisphere } from '@@/js/intl-const.js';
import { prefersReducedMotion } from '@@/js/config.js';
import { definePreferences } from './manager.js';
import type { Theme } from '@/theme.js';
import type { SoundType } from '@/utility/sound.js';
import type { Plugin } from '@/plugin.js';
import type { DeviceKind } from '@/utility/device-kind.js';
import type { DeckProfile } from '@/deck.js';
import type { WatermarkPreset } from '@/utility/watermark.js';
import { genId } from '@/utility/id.js';
import { DEFAULT_DEVICE_KIND } from '@/utility/device-kind.js';
import { deepEqual } from '@/utility/deep-equal.js';

/** サウンド設定 */
export type SoundStore = {
	type: Exclude<SoundType, '_driveFile_'>;
	volume: number;
} | {
	type: '_driveFile_';

	/** ドライブのファイルID */
	fileId: string;

	/** ファイルURL（こちらが優先される） */
	fileUrl: string;

	volume: number;
};

export type StatusbarStore = {
	name: string | null;
	id: string;
	type: string | null;
	size: 'verySmall' | 'small' | 'medium' | 'large' | 'veryLarge';
	black: boolean;
	props: Record<string, any>;
};

export type DataSaverStore = {
	media: boolean;
	avatar: boolean;
	urlPreviewThumbnail: boolean;
	disableUrlPreview: boolean;
	code: boolean;
};

type OmitStrict<T, K extends keyof T> = T extends any ? Pick<T, Exclude<keyof T, K>> : never;

// NOTE: デフォルト値は他の設定の状態に依存してはならない(依存していた場合、ユーザーがその設定項目単体で「初期値にリセット」した場合不具合の原因になる)

export const PREF_DEF = definePreferences({
	accounts: {
		default: [] as [host: string, user: {
			id: string;
			username: string;
		}][],
	},

	pinnedUserLists: {
		accountDependent: true,
		default: [] as Misskey.entities.UserList[],
	},
	uploadFolder: {
		accountDependent: true,
		default: null as string | null,
	},
	widgets: {
		accountDependent: true,
		default: () => [{
			name: 'calendar',
			id: genId(), place: 'right', data: {},
		}, {
			name: 'notifications',
			id: genId(), place: 'right', data: {},
		}, {
			name: 'trends',
			id: genId(), place: 'right', data: {},
		}] as {
			name: string;
			id: string;
			place: string | null;
			data: Record<string, any>;
		}[],
	},
	'deck.profile': {
		accountDependent: true,
		default: null as string | null,
	},
	'deck.profiles': {
		accountDependent: true,
		default: [] as DeckProfile[],
	},

	emojiPalettes: {
		serverDependent: true,
		default: () => [{
			id: genId(),
			name: '',
			emojis: ['👍', '❤️', '😆', '🤔', '😮', '🎉', '💢', '😥', '😇', '🍮'],
		}] as {
			id: string;
			name: string;
			emojis: string[];
		}[],
		mergeStrategy: (a, b) => {
			const mergedItems = [] as typeof a;
			for (const x of a.concat(b)) {
				const sameIdItem = mergedItems.find(y => y.id === x.id);
				if (sameIdItem != null) {
					if (deepEqual(x, sameIdItem)) { // 完全な重複は無視
						continue;
					} else { // IDは同じなのに内容が違う場合はマージ不可とする
						throw new Error();
					}
				} else {
					mergedItems.push(x);
				}
			}
			return mergedItems;
		},
	},
	emojiPaletteForReaction: {
		serverDependent: true,
		default: null as string | null,
	},
	emojiPaletteForMain: {
		serverDependent: true,
		default: null as string | null,
	},

	overridedDeviceKind: {
		default: null as DeviceKind | null,
	},
	themes: {
		default: [] as Theme[],
		mergeStrategy: (a, b) => {
			const mergedItems = [] as typeof a;
			for (const x of a.concat(b)) {
				const sameIdItem = mergedItems.find(y => y.id === x.id);
				if (sameIdItem != null) {
					if (deepEqual(x, sameIdItem)) { // 完全な重複は無視
						continue;
					} else { // IDは同じなのに内容が違う場合はマージ不可とする
						throw new Error();
					}
				} else {
					mergedItems.push(x);
				}
			}
			return mergedItems;
		},
	},
	lightTheme: {
		default: null as Theme | null,
	},
	darkTheme: {
		default: null as Theme | null,
	},
	syncDeviceDarkMode: {
		default: true,
	},
	defaultNoteVisibility: {
		default: 'public' as (typeof Misskey.noteVisibilities)[number],
	},
	defaultNoteLocalOnly: {
		default: false,
	},
	keepCw: {
		default: true,
	},
	rememberNoteVisibility: {
		default: false,
	},
	reportError: {
		default: false,
	},
	collapseRenotes: {
		default: true,
	},
	menu: {
		default: [
			'notifications',
			'chat',
			'favorites',
                        'portal',
			'hatask',
			'hataDocs',
			'explore',
			'followRequests',
			'-',
			'announcements',
			'channels',
			'search',
			'-',
		],
	},
	statusbars: {
		default: [] as StatusbarStore[],
	},
	serverDisconnectedBehavior: {
		default: 'quiet' as 'quiet' | 'reload' | 'dialog' | 'none',
	},
	nsfw: {
		default: 'respect' as 'respect' | 'force' | 'ignore',
	},
	highlightSensitiveMedia: {
		default: false,
	},
	animation: {
		default: !prefersReducedMotion,
	},
	animatedMfm: {
		default: !prefersReducedMotion,
	},
	advancedMfm: {
		default: true,
	},
	showReactionsCount: {
		default: true,
	},
	enableQuickAddMfmFunction: {
		default: true,
	},
	loadRawImages: {
		default: false,
	},
	imageNewTab: {
		default: false,
	},
	disableShowingAnimatedImages: {
		default: prefersReducedMotion,
	},
	emojiStyle: {
		default: 'twemoji', // twemoji / fluentEmoji / native
	},
	menuStyle: {
		default: 'auto' as 'auto' | 'popup' | 'drawer',
	},
	useBlurEffectForModal: {
		default: true,
	},
	useBlurEffect: {
		default: true,
	},
	useStickyIcons: {
		default: true,
	},
	enableHighQualityImagePlaceholders: {
		default: true,
	},
	showFixedPostForm: {
		default: false,
	},
	showFixedPostFormInChannel: {
		default: false,
	},
	enableInfiniteScroll: {
		default: true,
	},
	useReactionPickerForContextMenu: {
		default: false,
	},
	showGapBetweenNotesInTimeline: {
		default: true,
	},
	instanceTicker: {
		default: 'remote' as 'none' | 'remote' | 'always',
	},
	emojiPickerScale: {
		default: 3,
	},
	emojiPickerWidth: {
		default: 2,
	},
	emojiPickerHeight: {
		default: 3,
	},
	emojiPickerStyle: {
		default: 'auto' as 'auto' | 'popup' | 'drawer',
	},
	squareAvatars: {
		default: true,
	},
	showAvatarDecorations: {
		default: true,
	},
	numberOfPageCache: {
		default: 3,
	},
	pollingInterval: {
		// 1 ... 低
		// 2 ... 中
		// 3 ... 高
		default: 2,
	},
	showNoteActionsOnlyHover: {
		default: false,
	},
	showClipButtonInNoteFooter: {
		default: false,
	},
	reactionsDisplaySize: {
		default: 'small' as 'small' | 'medium' | 'large',
	},
	limitWidthOfReaction: {
		default: true,
	},
	forceShowAds: {
		default: true,
	},
	aiChanMode: {
		default: false,
	},
	devMode: {
		default: false,
	},
	mediaListWithOneImageAppearance: {
		default: 'expand' as 'expand' | '16_9' | '1_1' | '2_3',
	},
	notificationPosition: {
		default: 'rightBottom' as 'leftTop' | 'leftBottom' | 'rightTop' | 'rightBottom',
	},
	notificationStackAxis: {
		default: 'vertical' as 'vertical' | 'horizontal',
	},
	enableCondensedLine: {
		default: false,
	},
	keepScreenOn: {
		default: false,
	},
	useGroupedNotifications: {
		default: true,
	},
	dataSaver: {
		default: {
			media: false,
			avatar: false,
			urlPreviewThumbnail: false,
			disableUrlPreview: false,
			code: false,
		} as DataSaverStore,
	},
	hemisphere: {
		default: hemisphere as 'N' | 'S',
	},
	enableSeasonalScreenEffect: {
		default: false,
	},
	enableHorizontalSwipe: {
		default: false,
	},
	enablePullToRefresh: {
		default: true,
	},
	useNativeUiForVideoAudioPlayer: {
		default: false,
	},
	keepOriginalFilename: {
		default: true,
	},
	alwaysConfirmFollow: {
		default: true,
	},
	confirmWhenRevealingSensitiveMedia: {
		default: false,
	},
	contextMenu: {
		default: 'app' as 'app' | 'appWithShift' | 'native',
	},
	skipNoteRender: {
		default: true,
	},
	showSoftWordMutedWord: {
		default: false,
	},
	confirmOnReact: {
		default: false,
	},
	defaultFollowWithReplies: {
		default: true,
	},
	makeEveryTextElementsSelectable: {
		default: DEFAULT_DEVICE_KIND === 'desktop',
	},
	showNavbarSubButtons: {
		default: true,
	},
	showTitlebar: {
		default: false,
	},
	showAvailableReactionsFirstInNote: {
		default: false,
	},
	showPageTabBarBottom: {
		default: false,
	},
	plugins: {
		default: [] as (OmitStrict<Plugin, 'config'> & { config: Record<string, any> })[],
		mergeStrategy: (a, b) => {
			const sameIdExists = a.some(x => b.some(y => x.installId === y.installId));
			if (sameIdExists) throw new Error();
			const sameNameExists = a.some(x => b.some(y => x.name === y.name));
			if (sameNameExists) throw new Error();
			return a.concat(b);
		},
	},
	mutingEmojis: {
		default: [] as string[],
		mergeStrategy: (a, b) => {
			return [...new Set(a.concat(b))];
		},
	},
	watermarkPresets: {
		accountDependent: true,
		default: [] as WatermarkPreset[],
		mergeStrategy: (a, b) => {
			const mergedItems = [] as typeof a;
			for (const x of a.concat(b)) {
				const sameIdItem = mergedItems.find(y => y.id === x.id);
				if (sameIdItem != null) {
					if (deepEqual(x, sameIdItem)) { // 完全な重複は無視
						continue;
					} else { // IDは同じなのに内容が違う場合はマージ不可とする
						throw new Error();
					}
				} else {
					mergedItems.push(x);
				}
			}
			return mergedItems;
		},
	},
	defaultWatermarkPresetId: {
		accountDependent: true,
		default: null as WatermarkPreset['id'] | null,
	},
	defaultImageCompressionLevel: {
		default: 2 as 0 | 1 | 2 | 3,
	},
	defaultVideoCompressionLevel: {
		default: 2 as 0 | 1 | 2 | 3,
	},

	'sound.masterVolume': {
		default: 0.5,
	},
	'sound.notUseSound': {
		default: false,
	},
	'sound.useSoundOnlyWhenActive': {
		default: false,
	},
	'sound.on.note': {
		default: { type: 'syuilo/n-aec', volume: 1 } as SoundStore,
	},
	'sound.on.noteMy': {
		default: { type: 'syuilo/n-cea-4va', volume: 1 } as SoundStore,
	},
	'sound.on.noteSchedulePost': {
		default: { type: 'syuilo/n-cea', volume: 1 } as SoundStore,
	},
	'sound.on.noteEdited': {
		default: { type: 'syuilo/n-eca', volume: 1 } as SoundStore,
	},
	'sound.on.notification': {
		default: { type: 'syuilo/n-ea', volume: 1 } as SoundStore,
	},
	'sound.on.reaction': {
		default: { type: 'syuilo/bubble2', volume: 1 } as SoundStore,
	},
	'sound.on.chatMessage': {
		default: { type: 'syuilo/waon', volume: 1 } as SoundStore,
	},

	'deck.alwaysShowMainColumn': {
		default: true,
	},
	'deck.navWindow': {
		default: true,
	},
	'deck.useSimpleUiForNonRootPages': {
		default: true,
	},
	'deck.columnAlign': {
		default: 'center' as 'left' | 'right' | 'center',
	},
	'deck.columnGap': {
		default: 6,
	},
	'deck.menuPosition': {
		default: 'bottom' as 'right' | 'bottom',
	},
	'deck.navbarPosition': {
		default: 'left' as 'left' | 'top' | 'bottom',
	},
	'deck.wallpaper': {
		default: null as string | null,
	},

	'chat.showSenderName': {
		default: true,
	},
	'chat.sendOnEnter': {
		default: true,
	},

	'game.dropAndFusion': {
		default: {
			bgmVolume: 0.25,
			sfxVolume: 1,
		},
	},

	// #region CherryPick
	// - Settings/Appearance
	fontSize: {
		default: 8,
	},
	showUnreadNotificationsCount: {
		default: false,
	},
	setFederationAvatarShape: {
		default: true,
	},
	filesGridLayoutInUserPage: {
		default: true,
	},

	// - Settings/Timeline and Note
	forceCollapseAllRenotes: {
		default: false,
	},
	collapseReplies: {
		default: false,
	},
	collapseLongNoteContent: {
		default: true,
	},
	collapseDefault: {
		default: true,
	},
	allMediaNoteCollapse: {
		default: false,
	},
	showSubNoteFooterButton: {
		default: true,
	},
	infoButtonForNoteActionsEnabled: {
		default: true,
	},
	showTranslateButtonInNote: {
		default: true,
	},
	showGapBodyOfTheNote: {
		default: false,
	},
	showReplyButtonInNoteFooter: {
		default: true,
	},
	showRenoteButtonInNoteFooter: {
		default: true,
	},
	showLikeButtonInNoteFooter: {
		default: true,
	},
	showDoReactionButtonInNoteFooter: {
		default: true,
	},
	showQuoteButtonInNoteFooter: {
		default: true,
	},
	showMoreButtonInNoteFooter: {
		default: true,
	},
	selectReaction: {
		default: '❤️' as string,
	},
	showReplyInNotification: {
		default: false,
	},
	renoteQuoteButtonSeparation: {
		default: true,
	},
	renoteVisibilitySelection: {
		default: true,
	},
	forceRenoteVisibilitySelection: {
		default: 'none' as 'none' | 'public' | 'home' | 'followers',
	},
	showFixedPostFormInReplies: {
		default: true,
	},
	showNoAltTextWarning: {
		default: false,
	},
	alwaysShowCw: {
		default: false,
	},
	hideAvatarsInNote: {
		default: false,
	},
	enableAbsoluteTime: {
		default: false,
	},
	enableMarkByDate: {
		default: false,
	},
	showReplyTargetNote: {
		default: true,
	},
	showReplyTargetNoteInSemiTransparent: {
		default: true,
	},
	nsfwOpenBehavior: {
		default: 'click' as 'click' | 'doubleClick',
	},

	// - Settings/Posting form
	showPreview: {
		default: false,
	},
	showProfilePreview: {
		default: true,
	},

	// - Settings/Navigate to an external site warning
	externalNavigationWarning: {
		default: true,
	},
	trustedDomains: {
		default: [] as string[],
	},

	// - Settings/Accessibility
	showingAnimatedImages: {
		default: /mobile|ipad|iphone|android/.test(navigator.userAgent.toLowerCase()) ? 'inactive' : 'always' as 'always' | 'interaction' | 'inactive',
	},

	// - Settings/Performance
	removeModalBgColorForBlur: {
		default: DEFAULT_DEVICE_KIND === 'desktop',
	},
	smoothTransitionAnimations: {
		default: false,
	},

	// - Settings/Other
	autoLoadMoreReplies: {
		default: false,
	},
	autoLoadMoreConversation: {
		default: false,
	},
	useAutoTranslate: {
		default: false,
	},
	welcomeBackToast: {
		default: true,
	},
	disableNyaize: {
		default: false,
	},
	requireRefreshBehavior: {
		default: 'dialog' as 'quiet' | 'dialog',
	},
	newNoteReceivedNotificationBehavior: {
		default: 'count' as 'default' | 'count' | 'none',
	},

	// - Settings/Navigation bar
	bannerDisplay: {
		default: 'topBottom' as 'all' | 'topBottom' | 'top' | 'bottom' | 'bg' | 'hide',
	},

	// - Settings/Timeline
	enableHomeTimeline: {
		default: true,
	},
	enableLocalTimeline: {
		default: true,
	},
	enableSocialTimeline: {
		default: true,
	},
	enableGlobalTimeline: {
		default: true,
	},
	enableMediaTimeline: {
		default: true,
	},
	enableBubbleTimeline: {
		default: true,
	},
	enableListTimeline: {
		default: true,
	},
	enableAntennaTimeline: {
		default: true,
	},
	enableChannelTimeline: {
		default: true,
	},

	// - Settings/CherryPick
	nicknameEnabled: {
		default: true,
	},
	nicknameMap: {
		default: {} as Record<string, string>,
	},
	useEnterToSend: {
		default: false,
	},
	postFormVisibilityHotkey: {
		default: true,
	},
	showRenoteConfirmPopup: {
		default: true,
	},
	expandOnNoteClick: {
		default: false,
        },
        timelineAnimationDirection: {
                default: 'left' as 'top' | 'left' | 'right' | 'random',
	},
	expandOnNoteClickBehavior: {
		default: 'click' as 'click' | 'doubleClick',
	},
	displayHeaderNavBarWhenScroll: {
		default: 'hideHeaderFloatBtn' as 'all' | 'hideHeaderOnly' | 'hideHeaderFloatBtn' | 'hideFloatBtnOnly' | 'hideFloatBtnNavBar' | 'hide',
	},
	reactableRemoteReactionEnabled: {
		default: true,
	},
	showFollowingMessageInsteadOfButtonEnabled: {
		default: true,
	},
	mobileHeaderChange: {
		default: false,
	},
	renameTheButtonInPostFormToNya: {
		default: false,
	},
	renameTheButtonInPostFormToNyaManualSet: {
		default: false,
        },
        showHashtagButtonInPostForm: {
                default: true,
        },
        showEventButtonInPostForm: {
                default: true,
	},
        showDrawingButtonInPostForm: {
		default: true,
	},
        useSimpleTL: {
        default: false,
	},
        simpleTLLastListId: {
        default: null as string | null,
        hidden: true, // 設定画面には出さない
        },
	enableWidgetsArea: {
		default: true,
	},
	friendlyUiEnableNotificationsArea: {
		default: true,
	},
	enableLongPressOpenAccountMenu: {
		default: true,
	},
	friendlyUiShowAvatarDecorationsInNavBtn: {
		default: false,
	},
	// ログインボーナスポップアップ表示設定（旗鯖独自機能）
	showLoginBonusPopup: {
		default: true,
	},
	// 外部サーバー連携（旗鯖独自機能）
	'external.enabled': {
		default: false,
	},
	'external.host': {
		default: 'mk.shrimpia.network' as string,
	},
	'external.token': {
		default: null as string | null,
	},
	'external.userId': {
		default: null as string | null,
	},
	'external.username': {
		default: null as string | null,
	},
	'external.enableOHTL': {
		default: true,
	},
	'external.enableOLTL': {
		default: true,
	},
	// ======== シンプルUI設定 ========
	'simpleUi.topNav': {
		default: [
			{ id: 'following', icon: 'ti ti-home', label: 'ホーム', visible: true },
			{ id: 'local', icon: 'ti ti-planet', label: 'ローカル', visible: true },
			{ id: 'social', icon: 'ti ti-users', label: 'ソーシャル', visible: false },
			{ id: 'mixed', icon: 'ti ti-universe', label: 'グローバル', visible: true },
		] as { id: string; icon: string; label: string; visible: boolean }[],
	},
	'simpleUi.bottomNav': {
		default: [
			{ id: 'search', icon: 'ti ti-search', label: '検索', visible: true },
			{ id: 'home', icon: 'ti ti-home', label: 'ホーム', visible: true },
			{ id: 'notifications', icon: 'ti ti-bell', label: '通知', visible: true },
			{ id: 'hatask', icon: 'ti ti-eye', label: '独自機能', visible: true },
			{ id: 'widgets', icon: 'ti ti-apps', label: 'ウィジェット', visible: false },
		] as { id: string; icon: string; label: string; visible: boolean }[],
	},
	'simpleUi.sidebar': {
		default: [
			{ id: 'timeline', icon: 'ti ti-home', label: 'タイムライン' },
			{ id: 'notifications', icon: 'ti ti-bell', label: '通知' },
			{ id: 'search', icon: 'ti ti-search', label: '検索' },
			{ id: 'hatask', icon: 'ti ti-eye', label: '独自機能' },
			{ id: 'lists', icon: 'ti ti-list', label: 'リスト' },
			{ id: 'channels', icon: 'ti ti-device-tv', label: 'チャンネル' },
			{ id: 'antennas', icon: 'ti ti-antenna', label: 'アンテナ' },
			{ id: 'drive', icon: 'ti ti-cloud', label: 'ドライブ' },
			{ id: 'more', icon: 'ti ti-dots', label: 'もっと' },
		] as { id: string; icon: string; label: string }[],
	},
	'simpleUi.widgetBorder': {
		default: true,
	},
	'simpleUi.directProfile': {
		default: false,
	},
	'simpleUi.glassEffect': {
		default: true,
	},
	'simpleUi.noteSpacing': {
		default: 'moderate' as 'compact' | 'moderate' | 'wide',
	},
	// ======== シンプルUI設定ここまで ========
	//#endregion

	'experimental.stackingRouterView': {
		default: false,
	},
	'experimental.enableFolderPageView': {
		default: false,
	},
	'experimental.enableHapticFeedback': {
		default: false,
	},
	'experimental.enableWebTranslatorApi': {
		default: false,
	},
});